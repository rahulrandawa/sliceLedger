const obj = {
    key : 213,
    goods : "warehouse"
}
const arry = ["hame", "lname"]


export {obj, arry};