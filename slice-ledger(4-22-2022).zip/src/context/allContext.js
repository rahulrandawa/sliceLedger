import {obj, arry} from '../context/contextData';
const data = {
    obj,
    arry
}

export default data;